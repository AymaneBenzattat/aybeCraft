--Q1
DECLARE
    cmd_no Commandes.Cmdno%type;
    prix Articles.Prix_Proposé%type;
BEGIN
SELECT Cmdno INTO cmd_no FROM Commandes WHERE Clno=106 AND Cmddate=(SELECT MAX(Cmddate) FROM Commandes WHERE Clno=106);
SELECT Prix_Proposé INTO prix FROM Articles WHERE Artno=3;
INSERT INTO Ln_Cmd VALUES(cmd_no,3,2,prix,0.08);
END;
--Q2
DECLARE
    cmd_no Commandes.Cmdno%type;
    prix Articles.Prix_Proposé%type;
    num_article Articles.Artnom%type;
    taux Ln_Cmd.Prix_Vente%type;
    remise Ln_Cmd.Taux_Remise%type;
BEGIN
SELECT Cmdno INTO cmd_no FROM Commandes WHERE Clno=102 AND Cmddate=(SELECT MAX(Cmddate) FROM Commandes WHERE Clno=102);
SELECT Artno INTO num_article FROM Articles WHERE Artnom='Processeur P3';
SELECT Prix_Proposé INTO prix FROM Articles WHERE Artno=num_article;
SELECT MIN(Prix_Vente) INTO taux FROM Ln_Cmd WHERE Artno=num_article;
IF prix>taux
THEN
    remise:=0.1;
ELSE
    remise:=0;
END IF;
INSERT INTO Ln_Cmd VALUES(cmd_no,num_article,2,taux,remise);
END;
--Q3
CREATE OR REPLACE FUNCTION cmdClient(cmd_no Commandes.Cmdno%type) return Commandes.Clnom%type
IS
v_result Commandes.Clnom%type;
BEGIN
  SELECT C.Clnom INTO v_result FROM Clients C, Commandes Cmd WHERE Cmd.Cmdno=cmd_no AND Cmd.Clno=C.Clno;
  RETURN v_result;
END;
/
--Q4
DECLARE
CURSOR c_article IS
SELECT Artno,Taux
FROM Articles;
articleno Articles.Artno%type;
v_taux Articles.Prix_Proposé%type;
v_qte Ln_Cmd.Qte%type;
v_avg Articles.Prix_Proposé%type;
BEGIN
OPEN c_article;
LOOP
FETCH c_article INTO articleno, v_taux;
SELECT SUM(qte) INTO v_qte FROM Ln_Cmd WHERE Artno=articleno;
SELECT AVG(Prix_Vente) INTO v_avg FROM Ln_Cmd WHERE Artno=articleno;
IF v_qte>5
THEN
v_taux:=v_taux*1.1;
    UPDATE Articles SET Prix_Proposé=v_taux WHERE Artno=articleno;
END IF;
IF v_taux>v_avg
THEN
v_taux:=v_taux*0.97;
    UPDATE Articles SET Prix_Proposé=v_taux WHERE Artno=articleno;
END IF;
IF v_taux<v_avg
THEN
v_taux:=v_taux*1.02;
    UPDATE Articles SET Prix_Proposé=v_taux WHERE Artno=articleno;
END IF;
exit when c_article%notfound;
END LOOP;
EXCEPTION
WHEN no_data_found THEN
    dbms_output.put_line('Erreur');
END;
--Q5:
CREATE OR REPLACE TRIGGER checkHeure
    BEFORE INSERT OR UPDATE OR DELETE ON Articles
    FOR EACH ROW
BEGIN
    DECLARE heure number;
    SELECT to_number(to_char(SYSDATE, 'HH24')) INTO heure FROM DUAL;
    IF (heure < 9) OR (heure > 21)
    THEN
        raise_application_error(-123, 'Modification interdite entre 21h et 9h');
    END IF;
    END;
--Q6:
CREATE OR REPLACE TRIGGER ligneCheck
    BEFORE INSERT ON Ln_Cmd
    FOR EACH ROW
BEGIN
    DECLARE v_total number;
    SELECT Count(L.Artno) INTO v_total FROM Ln_Cmd L WHERE L.Cmdno=:new.Cmdno;
    IF (v_total >= 5)
    THEN
        RAISE_APPLICATION_ERROR(-124, 'Pas plus de 5 lignes par commande'); 
    END IF;
    END;
--Q7:
CREATE OR REPLACE TRIGGER prixCheck
    BEFORE UPDATE OF Taux ON Articles
    FOR EACH ROW
BEGIN
    DECLARE p_25 number;
    p_25:=:old.Prix_Proposé*1.25;
    IF (:new.Prix_Proposé > p_25)
    THEN
        RAISE_APPLICATION_ERROR(-125, 'Pas plus de 25%'); 
    END IF;
END;
<?php

class HomeController
{
    public static function welcome()
    {
        View::return("home.php");
    }
}



?>
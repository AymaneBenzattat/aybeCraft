page1
<?= PHP_URL_HOST ?>
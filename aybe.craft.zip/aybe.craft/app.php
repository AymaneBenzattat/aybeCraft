<?php

const APPNAME="aybe.Craft";
const APPURL="localhost";
const APPKEY="";
const SETUP=true;
const DEBUG=false;

const DBHOST="localhost";
const DBNAME="hotel";
const DBUSER="root";
const DBPASS="";

?>